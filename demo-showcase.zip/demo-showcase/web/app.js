import init, { sign_payload } from "./pkg/signer_wasm.js";

let lastSignedJson = "";

async function readFileAsUint8Array(file) {
  const buffer = await file.arrayBuffer();
  return new Uint8Array(buffer);
}

function downloadTextFile(filename, text) {
  const blob = new Blob([text], { type: "application/json" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();

  URL.revokeObjectURL(url);
}

async function main() {
  await init();

  const documentInput = document.getElementById("documentFile");
  const keyInput = document.getElementById("keyFile");
  const nameInput = document.getElementById("nameInput");
  const messageInput = document.getElementById("messageInput");
  const signBtn = document.getElementById("signBtn");
  const downloadBtn = document.getElementById("downloadBtn");
  const output = document.getElementById("output");

  if (!documentInput || !keyInput || !nameInput || !messageInput || !signBtn || !downloadBtn || !output) {
    alert("Falta al menos un elemento del HTML.");
    return;
  }

  signBtn.addEventListener("click", async () => {
    try {
      const documentFile = documentInput.files[0];
      const keyFile = keyInput.files[0];
      const name = nameInput.value;
      const message = messageInput.value;

      if (!documentFile) {
        output.value = "Selecciona un documento.";
        return;
      }

      if (!keyFile) {
        output.value = "Selecciona la private key.";
        return;
      }

      const documentBytes = await readFileAsUint8Array(documentFile);
      const privateKeyPem = await keyFile.text();

      const signedJson = sign_payload(documentBytes, privateKeyPem, name, message);

      lastSignedJson = signedJson;
      output.value = signedJson;
    } catch (err) {
      output.value = `Error: ${err}`;
      console.error(err);
    }
  });

  downloadBtn.addEventListener("click", () => {
    if (!lastSignedJson) {
      output.value = "Primero genera una firma.";
      return;
    }

    downloadTextFile("signed_payload.json", lastSignedJson);
  });
}

main();