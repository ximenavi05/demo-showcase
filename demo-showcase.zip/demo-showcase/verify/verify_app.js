async function fileToBase64(file) {
    const buffer = await file.arrayBuffer();
    let binary = "";
    const bytes = new Uint8Array(buffer);
  
    for (let i = 0; i < bytes.length; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
  
    return btoa(binary);
  }
  
  async function main() {
    const documentInput = document.getElementById("documentFile");
    const payloadInput = document.getElementById("payloadFile");
    const publicKeyInput = document.getElementById("publicKeyFile");
    const verifyBtn = document.getElementById("verifyBtn");
    const output = document.getElementById("output");
  
    verifyBtn.addEventListener("click", async () => {
      try {
        const documentFile = documentInput.files[0];
        const payloadFile = payloadInput.files[0];
        const publicKeyFile = publicKeyInput.files[0];
  
        if (!documentFile) {
          output.textContent = "Selecciona el documento.";
          return;
        }
  
        if (!payloadFile) {
          output.textContent = "Selecciona el signed_payload.json.";
          return;
        }
  
        if (!publicKeyFile) {
          output.textContent = "Selecciona la public key.";
          return;
        }
  
        const documentBase64 = await fileToBase64(documentFile);
        const payloadText = await payloadFile.text();
        const signedPayload = JSON.parse(payloadText);
        const publicKeyPem = await publicKeyFile.text();
  
        const response = await fetch("http://127.0.0.1:9002/verify", {
          method: "POST",
          headers: {
            "Content-Type": "application/json"
          },
          body: JSON.stringify({
            document_base64: documentBase64,
            signed_payload: signedPayload,
            public_key_pem: publicKeyPem
          })
        });
  
        const result = await response.json();
        output.textContent = JSON.stringify(result, null, 2);
      } catch (err) {
        output.textContent = `Error: ${err}`;
      }
    });
  }
  
  main();
