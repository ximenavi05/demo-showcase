import json
import hashlib
from http.server import BaseHTTPRequestHandler, HTTPServer
import base64

from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.exceptions import InvalidSignature


def build_canonical_payload(name: str, message: str, document_hash_hex: str) -> bytes:
    text = f"name={name.strip()}\nmessage={message.strip()}\ndocument_hash_hex={document_hash_hex}"
    return text.encode("utf-8")


class VerifyHandler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        if self.path != "/verify":
            self.send_response(404)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(b"Not found")
            return

        content_length = int(self.headers.get("Content-Length", "0"))
        raw_body = self.rfile.read(content_length)

        try:
            data = json.loads(raw_body.decode("utf-8"))

            document_b64 = data["document_base64"]
            signed_payload = data["signed_payload"]
            public_key_pem = data["public_key_pem"]

            document_bytes = base64.b64decode(document_b64)

            name = signed_payload["name"]
            message = signed_payload["message"]
            document_hash_hex = signed_payload["document_hash_hex"]
            signature_base64 = signed_payload["signature_base64"]

            recalculated_hash_hex = hashlib.sha256(document_bytes).hexdigest()

            if recalculated_hash_hex != document_hash_hex:
                response = {
                    "valid": False,
                    "reason": "El hash del documento no coincide",
                }
                self._send_json(response)
                return

            payload_bytes = build_canonical_payload(name, message, document_hash_hex)

            public_key = serialization.load_pem_public_key(public_key_pem.encode("utf-8"))
            signature_bytes = base64.b64decode(signature_base64)

            public_key.verify(
                signature_bytes,
                payload_bytes,
                padding.PKCS1v15(),
                hashes.SHA256(),
            )

            response = {
                "valid": True,
                "name": name,
                "message": message,
                "result": f"Sí, esta firma digital corresponde a {name}",
            }
            self._send_json(response)

        except InvalidSignature:
            self._send_json({
                "valid": False,
                "reason": "La firma no es válida para esta public key",
            })
        except Exception as e:
            self._send_json({
                "valid": False,
                "reason": f"Error: {str(e)}",
            })

    def _send_json(self, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)


if __name__ == "__main__":
    server = HTTPServer(("127.0.0.1", 9002), VerifyHandler)
    print("Servidor de verificación en http://127.0.0.1:9002")
    server.serve_forever()